package com.lmps.security;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import com.lmps.common.model.GroupLicenseTypeMapping;
import com.lmps.common.model.UserRoleMappingUtility;

/**
 * Spring security to create in-memory users with roles
 * 
 * @author aonkar
 *
 */
@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Autowired
	AuthenticationFilter loginFilter;

	@Value(value = "$resourceManager{}")
	String resourceManager;

	@Value(value = "${commonUser}")
	String commonUser;

	@Value(value = "${ldap_grp_role_mapping}")
	String ldapGrpRoleMapping;

	@Value(value = "${groups_modifier_list}")
	String groupsModifierList;

	/**
	 * Authorize the users based on the roles
	 */

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {}

	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {

		httpSecurity.csrf().disable();
		httpSecurity.authorizeRequests().antMatchers(HttpMethod.POST, "/sign-in").permitAll()
				.antMatchers(HttpMethod.POST, "/log-out").permitAll()
				.antMatchers(HttpMethod.POST, "/licenses/internal-from-api").permitAll()
				.antMatchers(HttpMethod.GET, "/licenses/thirdparty/form-fields")
				.hasAnyRole(UserRolesEnum.COMMON_USER.toString(), UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.GET, "/licenses/customers/form-fields")
				.hasRole(UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.GET, "/licenses/developers/form-fields")
				.hasRole(UserRolesEnum.RESOURCE_MANAGER.toString()).antMatchers(HttpMethod.POST, "/licenses/internal")
				.hasAnyRole(UserRolesEnum.COMMON_USER.toString(), UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/licenses/thirdparty")
				.hasAnyRole(UserRolesEnum.COMMON_USER.toString(), UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/licenses/customers").hasRole(UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/licenses/developers").hasRole(UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/customers").hasRole(UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/partners").hasRole(UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/customers/data").hasRole(UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/partners/data").hasRole(UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/licenses")
				.hasAnyRole(UserRolesEnum.COMMON_USER.toString(), UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/licenses/data")
				.hasAnyRole(UserRolesEnum.COMMON_USER.toString(), UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/licenses/download")
				.hasAnyRole(UserRolesEnum.COMMON_USER.toString(), UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/licenses/preview")
				.hasAnyRole(UserRolesEnum.COMMON_USER.toString(), UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/licenses/details").hasRole(UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "/licenses/activation-deactivation")
				.hasRole(UserRolesEnum.RESOURCE_MANAGER.toString())
				.antMatchers(HttpMethod.POST, "licenses/activation-details")
				.hasRole(UserRolesEnum.RESOURCE_MANAGER.toString());
		httpSecurity.addFilterBefore(loginFilter, BasicAuthenticationFilter.class);

	}

}
