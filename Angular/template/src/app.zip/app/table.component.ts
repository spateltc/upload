import { Component,Input, OnChanges  } from '@angular/core';
import { DatePipe } from '@angular/common';
import { TableService } from './fetch.service';
import { TableAccount } from './TableAccount';
import { Subscription }   from 'rxjs/Subscription';
import { SlicePipe } from '@angular/common';
import * as _ from 'lodash';
import { DecimalPipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { headerComponent } from './header.component';


declare var google: any;
@Component({
  selector: 'tabl',
  template: `<header></header>
  <h1>
         <font size="4"><span>Legacy Charter C3 Audit For {{locParam}}</span></font> <br/>     
  </h1>
  <h1>
         <font size="3"><span>Start date</span></font>   
         <input type="date"  id="startDate"  (change)="dateBasedValueFetch()"  >   
 
         <font size="3"><span>End date</span></font>   
         <input type="date" id="endDate"  (change)="dateBasedValueFetch()" >   
  </h1>


  <!--<input type="date" id="endDate"  [(ngModel)]="endDat"  >   -->
  <!--<input type="date"  id="startDate" [(ngModel)]="startDat" (change)="dateBasedValueFetch()"  > -->
  
  <table id="customers">
  <tr>
    <th  style="width: 250px;text-align: left;">  Add TimeStamp (MDT)</th>  
    <th> Deluxe</th>
    <th> Alphanso</th>
    <th>  Digital Smith  </th>  
    <th> Mapped Assets</th>
    <th> DS/ Deluxe %</th>
    <th> Mapped Deluxe %</th>
    <th> Link to Detail Report</th>
  </tr>

  <tr *ngFor="let row of barChartData" class="alnright">
    <td align="left">{{row.add_TIMESTAMP | slice:0:16}}</td> 
    <td>{{row.deluxe}}</td>
    <td>{{row.alphanso}}</td>
    <td>{{row.digital_SMITH}}</td>
    <td>{{row.mapped_ASSETS}}</td>
    <td>{{row.digital_SMITH}}</td>
    <td>{{row.ds_DELUXE}}</td>
  <!--  <td>{{(row.digital_SMITH/row.deluxe)*100 | number:'2.0-0'}} %</td>
    <td>{{(row.mapped_ASSETS/row.deluxe)*100 | number:'2.0-0'}} %</td>    -->
    <td><a href={{row.link_TO_REPORT}}>Click Here</a></td>				
  </tr>
  <tr   *ngIf="barChartData.length <= 0" class="alnright">
    <td align="left">-</td> 
    <td>-</td>
    <td>-</td>
    <td>-</td>
    <td>-</td>
    <td>-</td>
    <td>-</td>
    <td>-</td>				
  </tr>
</table>

`,
  styles: [`
    .card {
      height: 70px;
      width: 100px;
    }
    .major {
      font-weight: bold;
    }
  
.alnright { text-align: center; }

#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
    font-size: 70%;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 10px;
    padding-bottom: 10px;
    text-align: center;
    background-color: #369;
    color: white;
    font-size: 75%;
}
  `],
  providers: [TableService]

})
export class TableComponent {
  title = 'app';
  public startDat;
  public endDat;
  public sub;
  public locParam;
  
    
public barChartData:any[];

    constructor(private _tableService:TableService,
     private route: ActivatedRoute,
    private router: Router) {
    }

    			startDateEnddate(i){
  //  this.setDob = datePipe.transform(userdate, 'dd/MM/yyyy');  
    //if((this.tableData[i][0] - this.endDat <= 0) && (this.tableData[i][0] - this.startDat >= 0) )
      //  return true;
   // else
     //   return false;g 
}		

servicecall(startDateValue:String,endDateValue:String,reportName:String):void{
this._tableService.getTables(startDateValue,endDateValue,reportName,this.locParam)
        .subscribe(restableData =>{
          
           this.barChartData = restableData;console.log('response data ',restableData);
           if(this.barChartData.length>0){
           this.locParam=this.barChartData[0].location;
           alert(this.barChartData[0].location);
           }
          });
}

  dateBasedValueFetch(): void {
     
      var   startDateValue= ((document.getElementById("startDate") as HTMLInputElement).value);
      var   endDateValue= ((document.getElementById("endDate") as HTMLInputElement).value);
     
      this.barChartData=null;
      this.servicecall(startDateValue,endDateValue,"C3 Audit");
  }

   ngOnInit(): void {
      this.sub = this.route
      .queryParams
      .subscribe(queryParams => {
        // Defaults to 0 if no query param provided.
        this.locParam = queryParams['locParam'];
        console.log('sashank location',this.locParam);
      });

  var Modelocation = "${quboBean.location}";
  var ModelEndDateValue = "${quboBean.endDateValue}";
  var ModelstartDateValue = "${quboBean.startDateValue}";
  var ModelreportName = "${quboBean.reportName}";
  console.log("Shashank Model Objects",Modelocation,ModelEndDateValue,ModelstartDateValue,ModelreportName);


  var y = document.getElementById("mydate");
  var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();
  var day;
  var mon;

if(dd<10) {
    day = '0'+dd;
}else{
day=dd;
}

if(mm<10) {
    mon = '0'+mm;
} else{
  mon=mm;
}

        //console.log('shashank',this.barChartData);
var currentDate = yyyy + '-' + mon  + '-' + day;
console.log(currentDate);
//alert(currentDate);
  //  y.defaultValue = currentDate;
    //document.getElementById("startDate").value=currentDate;
    (<HTMLInputElement>document.getElementById("startDate")).value=currentDate;
    this.startDat=currentDate;
   // alert(startDate);
     (<HTMLInputElement>document.getElementById("endDate")).value=currentDate;
     //this.endDat = currentDate.toISOString().substring(0, 10);
     this.endDat=currentDate;
     //alert(endDate);
   //   document.getElementById('startDate').value = new Date();
     //  document.getElementById("startDate").value = "2014-02-09";

     var   startDateValue= ((document.getElementById("startDate") as HTMLInputElement).value);
     var   endDateValue= ((document.getElementById("endDate") as HTMLInputElement).value);
     this.servicecall(startDateValue,endDateValue,"C3 Audit");
    }
}
