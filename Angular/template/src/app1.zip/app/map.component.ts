import { Component,NgZone } from '@angular/core';
import { TableService } from './fetch.service';
import { Router } from '@angular/router';

declare var google: any;
@Component({
  selector: 'map',
  template: `


<!--<div class="container-fluid">
    <div class="col-xs-12 col-md-10 col-md-offset-1 col-lg-8 col-lg-offset-2">
 <nav>  margin: auto !important;-->

 <div  id="map"  style="width: 1195px !important;margin-left: 0.8cm; margin-top: 0.5cm; height: 500px !important; 
    border: 1px solid GREY !important;
    padding: 1px !important; "></div>
  <!--</nav>
  </div>
  </div>-->
  `
})
export class mapComponent {
  title = 'app';
  public barChartData:any[];

    constructor(
        private _tableService:TableService,
        private router: Router,
        private ngZone:NgZone
    ) {}


  ngOnInit() {
    
  var locations = [
      ['St Louis: Last Executed 15-Dec-2017 13:00 MDT', 38.626871, -90.199527, 4,'red'],
      ['Dallas: Last Executed 20-Dec-2017 20:00 MDT', 32.799577, -96.811239, 5,'blue'],
      ['Rochester: Last Executed 20-Dec-2017 11:00 MDT', 43.163061, -77.613662, 3,'yellow'],
      ['New York: Last Executed 24-Dec-2017 19:00 MDT', 40.716099, -74.001609, 2,'green'],
      ['California : Last Executed 20-Dec-2017 08:00 MDT', 36.692892, -120.108414, 1,'orange']
    ];
var infowindow = new google.maps.InfoWindow();

    var marker, i;
    var loca;

   this._tableService.getmapLocations()
        .subscribe(restableData =>{ this.barChartData = restableData;
          console.log('response data',restableData);
          console.log('response data',this.barChartData.length);

           var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 4,
      center: new google.maps.LatLng(34.626871, -109.199527),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });


    var customMapType = new google.maps.StyledMapType([
      {
        elementType: 'labels',
        stylers: [{visibility: 'off'}]
      }
    ], {
      name: 'Custom Style'
  });


    

    for (i = 0; i < this.barChartData.length; i++) {  
      marker = new google.maps.Marker({  
        position: new google.maps.LatLng(this.barChartData[i].latitude, this.barChartData[i].longitude), 
		icon: 'http://maps.google.com/mapfiles/ms/icons/'+this.barChartData[i].color+'.png', 
  //	icon: 'http://maps.google.com/mapfiles/ms/icons/grey.png', 
        map: map 
      }); 

      
	 loca = this.barChartData;
  var loc=this.barChartData[i].locati;
  //console.log('location shashank',loc , i,this.barChartData[i].color);
      google.maps.event.addListener(marker, 'mouseover', (function(marker, i) {
        return function() {
         // console.log('location',this.barChartData[i].locati);
         console.log('location',loc,i);
         console.log('location shashank',loca);
          infowindow.setContent(loca[i].location +" Last Executed: "+ loca[i].lastExecuted);
          //infowindow.setContent("Location");
          infowindow.open(map, marker);
        }
      })(marker, i));

      google.maps.event.addListener(marker, 'click', ((marker, i) => {
        return ()=> {
         // console.log('location',this.barChartData[i].locati);
       this.ngZone.run(() =>  this.router.navigate(['/table']));
        }
      })(marker, i));
	//    var customMapTypeId = 'custom_style';
  //map.mapTypes.set(customMapTypeId, customMapType);
  //map.setMapTypeId(customMapTypeId);
    }
        });

 document.getElementById('map').style.display = 'block';
}


 hideDiv() {
    document.getElementById("map").style.display = "none";
}



}
