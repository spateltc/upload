export class TableAccount {
  timeStamp: string;
  Deluxe: number;
  Alphanso: number;
  DigitalSmith: number;
  MappedAssets: number;
  DSDeluxe: number;
  MappedDeluxe: number;
  LinktoDetailReport: number;
  }


