import { Component } from '@angular/core';
import { TableService } from './fetch.service';
declare var google: any;
@Component({
  selector: 'app-root',
  template: `<ul>
  <li style="float:left"><a href="/"><img  src="spectrumLogo.png"   style="width:100px;height:25px;"> </a></li>
  <li style="float:right"> <a href="/" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-log-out"></span> Log out
        </a></li>
</ul><router-outlet></router-outlet>`
})
export class AppComponent {

}
