import { Injectable } from "@angular/core";
import { Http,Response,Headers } from "@angular/http";
import 'rxjs/add/operator/map';
import {RequestOptions} from "@angular/http";
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
@Injectable()
export class TableService{
 
 //   private context: string = "http://localhost:8080/TWB"
   // private context: string = "http://10.118.5.248:8081/TWB"
     private _url: string ="http://localhost:8080/GhostRider/ords/preprod/MapReportTable"
     private _url2: string ="http://localhost:8080/TWB/ords/preprod/getEntityNames"
  
    public planName: String ;
    private _url3: string ="http://localhost:8080/TWB/ords/preprod/drawChart"
    private getReadableNamesForCategory: string ="http://localhost:8080/TWB/ords/preprod/getReadableNamesForCategory"
    private distinctvalue: string ="http://localhost:8080/TWB/ords/preprod/distinctStatus"
    private getwebtableColumnNames: string = "http://localhost:8080/TWB/ords/preprod/getReadableNamesForColumn"
    private subject = new Subject<any>();

    _chartData:any;
    responseTxt:any;
  
    constructor(private _http: Http){}
    getTables(startDateValue:String,endDateValue:String,reportName:String){
        
        var header = new Headers();
        var options=new RequestOptions();
        //var _url=this._url+"?"+"ReportName="+"C3 Audit";
        var _url=this._url+"?"+"startDateValue="+startDateValue+"&endDateValue="+endDateValue+"&reportName="+reportName;
        console.log('Network Call',_url);
        header.append('Content-Type', 'application/json');
        header.append('Access-Control-Allow-Origin','*');
        header.append('Access-Control-Allow-Headers','Content-Type');
        header.append('Access-Control-Allow-Methods','GET, POST, PUT, DELETE, OPTIONS');
        return this._http.get(_url,options)
        .map((response:Response) => response.json()).do((res) => {
            console.log('shashank',res);
        });
    }


    getmapLocations(){
        var header = new Headers();
        var options=new RequestOptions();
        //var _url=this._url+"?"+"ReportName="+"C3 Audit";
        var _url='http://localhost:8080/GhostRider/ords/preprod/MapLocation';
        console.log('Network Call',_url);
        header.append('Content-Type', 'application/json');
        header.append('Access-Control-Allow-Origin','*');
        header.append('Access-Control-Allow-Headers','Content-Type');
        header.append('Access-Control-Allow-Methods','GET, POST, PUT, DELETE, OPTIONS');
        return this._http.get(_url,options)
        .map((response:Response) => response.json()).do((res) => {
            console.log(res);
        });
    }

     getCategory(param : String){
          var _url3=this._url2+"?"+"entity="+"C3 Audit";
        var header = new Headers();
        var options=new RequestOptions();
header.append('Content-Type', 'application/json');
header.append('Access-Control-Allow-Origin','*');
header.append('Access-Control-Allow-Headers','Content-Type');
header.append('Access-Control-Allow-Methods','GET, POST, PUT, DELETE, OPTIONS');
        return this._http.get(_url3,options)
        .map((response:Response) => response.json())
        .do((res) => {
            console.log(res);
        });

    }


    drawChart( planName : String, entity : string ,category : string,chartName:string ): Observable<any[]>{
        this.planName=planName;
        var _url4=this._url3+"?"+"planName="+planName+"&entity="+entity+"&category="+category+"&chartType="+chartName;
        console.log("fetch service->"+_url4);
        var header = new Headers();
        var options=new RequestOptions();
    header.append('Content-Type', 'application/json');
    header.append('Access-Control-Allow-Origin','*');
    header.append('Access-Control-Allow-Headers','Content-Type');
    header.append('Access-Control-Allow-Methods','GET, POST, PUT, DELETE, OPTIONS');
    console.log("draw chart action "+_url4);
        return this._http.get(_url4,options)
        .map((response:Response) => response.json())
        .do((res) => {
            console.log(res);
        });
    }


      getReadableNames( planName : String ): Observable<any[]>{
        var _url4=this.getReadableNamesForCategory+"?"+"planName="+planName;
        console.log("fetch service->"+_url4);
        var header = new Headers();
        var options=new RequestOptions();
    header.append('Content-Type', 'application/json');
    header.append('Access-Control-Allow-Origin','*');
    header.append('Access-Control-Allow-Headers','Content-Type');
    header.append('Access-Control-Allow-Methods','GET, POST, PUT, DELETE, OPTIONS');
    console.log("draw chart action "+_url4);
        return this._http.get(_url4,options)
        .map((response:Response) => response.json())
        .do((res) => {
            console.log(res);
        });
 
    }



          getWebtableColumn( planName : String,entity : string ): Observable<any[]>{
        var _url9=this.getwebtableColumnNames+"?"+"planName="+planName+"&entity="+entity;
        console.log("fetch service->"+_url9);
        var header = new Headers();
        var options=new RequestOptions();
    header.append('Content-Type', 'application/json');
    header.append('Access-Control-Allow-Origin','*');
    header.append('Access-Control-Allow-Headers','Content-Type');
    header.append('Access-Control-Allow-Methods','GET, POST, PUT, DELETE, OPTIONS');
    console.log("draw chart action "+_url9);
        return this._http.get(_url9,options)
        .map((response:Response) => response.json())
        .do((res) => {
            console.log(res);
        });
 
    }



    getdistinctvalue( planName : String ): Observable<any[]>{
        this.planName=planName;
        var _url4=this.distinctvalue+"?"+"planName="+planName;
        console.log("fetch service->"+_url4);
        var header = new Headers();
        var options=new RequestOptions();
    header.append('Content-Type', 'application/json');
    header.append('Access-Control-Allow-Origin','*');
    header.append('Access-Control-Allow-Headers','Content-Type');
    header.append('Access-Control-Allow-Methods','GET, POST, PUT, DELETE, OPTIONS');
    console.log("draw chart action "+_url4);
        return this._http.get(_url4,options)
        .map((response:Response) => response.json())
        .do((res) => {
            console.log(res);
        }
        );

      
 
    }

    setChartData(chartData:any){
    console.log("fetch service setchartdata"+chartData);
    this._chartData=chartData;
    this.subject.next(true);
    }

    pieChartListener (): Observable<any> {
        console.log("fetch service-->pieChartListener");
        return this.subject.asObservable();
    }
getChartData(){
     console.log("fetch service getchartdata"+this._chartData);
    return this._chartData;
}
}
