import { Injectable } from '@angular/core';
import { Http, Headers, Response,RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject }    from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map'
import { ConfigService } from './config.service';
import { NgSpinningPreloader } from 'ng2-spinning-preloader';
import { Router } from '@angular/router';


@Injectable()
export class AuthService {
  baseURL;
  private messageEvent = {};
  private newOrderEvent = new BehaviorSubject<Object>(this.messageEvent);
  newOrderEventAsObservable = this.newOrderEvent.asObservable();

  constructor(
    private http: Http,
    private configService : ConfigService,
    private ngSpinningPreloader : NgSpinningPreloader,
    private  _router: Router) {
    this.ngSpinningPreloader.stop();
  }
  


  login(user) {
    //console.log(user);
    let loginUrl: string = this.configService.getConfig('signInURL');
    let headers = new Headers();
    headers.append('Content-Type','application/json');
    headers.append('Access-Control-Allow-Origin','*');
    let options = new RequestOptions({ headers: headers, withCredentials: true });
    return this.http.post(loginUrl,user,options)
      .catch(this.handleError)
      .map((response: Response) => {
        
        console.log("Test : ", response);
        let responseObject = response.json();
        
        if (responseObject && responseObject.status) {
        // console.log(responseObject.responseObject.userName);
        // console.log(responseObject.responseObject.roles);
        // console.log(responseObject.responseObject.jwt);
        }else{
          console.log('Auth Failure');
        }

        if (responseObject && responseObject.status) {
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem('name', responseObject.responseObject.userName);
            let role : string = responseObject.responseObject.roles;
            localStorage.setItem('role', role.toLowerCase());
            localStorage.setItem('token', responseObject.responseObject.jwt);
            localStorage.setItem('displayName', responseObject.responseObject.displayName);
            localStorage.setItem('emailId', responseObject.responseObject.emailId);
            localStorage.setItem('loggedIn', "true");
        }
        return responseObject;
      });
  }

  // remove user from local storage to log user out
  logout() {
    
    console.log('logout');
    let headers = new Headers();
    headers.append('Content-Type','application/json');
    headers.append('Access-Control-Allow-Origin','*');
    headers.append('Authorization',localStorage.getItem('token'));
    let options = new RequestOptions({ headers: headers, withCredentials: true });
    this.http.get(this.configService.getConfig('logoutURL'),options).subscribe(response =>{
      localStorage.removeItem('name');
      localStorage.removeItem('role');
      localStorage.removeItem('token');
      localStorage.removeItem('validUser');
      localStorage.removeItem('displayName');
      localStorage.removeItem('emailId');
      localStorage.removeItem('loggedIn');
      this._router.navigate(['login']);
    },
    (e) =>{
      localStorage.removeItem('name');
      localStorage.removeItem('role');
      localStorage.removeItem('token');
      localStorage.removeItem('validUser');
      localStorage.removeItem('displayName');
      localStorage.removeItem('emailId');
      localStorage.removeItem('loggedIn');
      this._router.navigate(['login']);
    });
  }

  // Send Subscription information to server
  sendSubscription(subInfo){
    let urls :any = {}; //this.config.getConfig('urls');
    let sendSubUrl: string = this.baseURL + urls.sendSubUrl;
    return this.http.post(sendSubUrl,subInfo)
      .catch(this.handleError)
      .map((response: Response) => {
        //console.log('subscription info sent successfully. Response from sendSub '+response);
      });
  }


  handleError(error: any){
    console.log('error::',error)
    if(error.status == 401){
      console.log('error::401')
      return Observable.throw(error.status || 'Server Error');
    }else{
      return Observable.throw(error.json().error || 'Server Error');
    }
   
  }
}
