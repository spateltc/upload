import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule }   from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DataTableModule} from "angular2-datatable";
import { AppComponent } from './app.component';
import { DemoModule }   from './demo/demo.module';
import { DemoComponent }   from './demo/demo.component';
import { TableComponent } from './table.component';
import { mapComponent } from './map.component';
import { LoginComponent } from './login.component';
import { headerComponent } from './header.component';
import { TableService } from './fetch.service';


@NgModule({
  //use the component even which you use for the navigation 
 
  declarations: [
    AppComponent,
    TableComponent,
    mapComponent,
    LoginComponent,
    headerComponent
  ],
  imports: [
    BrowserModule,
    DemoModule,
    DataTableModule,
    FormsModule,
    RouterModule.forRoot([
    //  {path:'table',component: DemoComponent}
     {
        path:'',
       component: LoginComponent
      },
      {
       path:'map',
       component: mapComponent
      },
       {
       path:'table',
       component: TableComponent
      }
     // {path:'map',component: MapComponent}
      ]),
  ],
  providers: [TableService],
  bootstrap: [AppComponent]
})
export class AppModule { }
